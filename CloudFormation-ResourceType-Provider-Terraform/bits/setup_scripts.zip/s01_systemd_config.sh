#!/bin/bash -x
mkdir -p ~/.config/systemd/user
pushd ~/.config/systemd/user
wget https://kwdem0s.s3.amazonaws.com/cfn/public/cs/bits/server-side-systemd/terraform-apply%40.service
wget https://kwdem0s.s3.amazonaws.com/cfn/public/cs/bits/server-side-systemd/terraform-destroy%40.service
wget https://kwdem0s.s3.amazonaws.com/cfn/public/cs/bits/server-side-systemd/terraform-init%40.service
popd
systemctl --user daemon-reload
