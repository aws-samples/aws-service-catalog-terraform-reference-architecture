#!/bin/bash -x
AWS_DEFAULT_REGION=`curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep '\"region\"' | cut -d\" -f4`
export  AWS_DEFAULT_REGION
puppy=`ssh-keygen -E md5 -lf <(ssh-keyscan -t ed25519 $1) | sed -E 's/^.+MD5:([^ ]+) .+$/\1/'`
aws ssm put-parameter  --name "/cfn/terraform/ssh-fingerprint" --type "String" --value "$puppy" --overwrite