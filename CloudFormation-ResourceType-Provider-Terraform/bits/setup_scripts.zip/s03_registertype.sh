#!/bin/bash -x
EXECUTION_ROLE_ARN=$1
LOGGING_ROLE_ARN=$2
LOG_GROUP_NAME=$3
echo aws cloudformation register-type --region us-east-1 --type RESOURCE --type-name Cloudsoft::Terraform::Infrastructure --schema-handler-package s3://kwdem0s/cfn/public/cs/bits/cloudsoft-terraform-infrastructure.zip  --execution-role-arn $EXECUTION_ROLE_ARN --logging-config "{\"LogRoleArn\":\"$LOGGING_ROLE_ARN\",\"LogGroupName\": \"$LOG_GROUP_NAME\"}"
aws cloudformation register-type --region us-east-1 --type RESOURCE --type-name Cloudsoft::Terraform::Infrastructure --schema-handler-package s3://kwdem0s/cfn/public/cs/bits/cloudsoft-terraform-infrastructure.zip  --execution-role-arn $EXECUTION_ROLE_ARN --logging-config "{\"LogRoleArn\":\"$LOGGING_ROLE_ARN\",\"LogGroupName\": \"$LOG_GROUP_NAME\"}"