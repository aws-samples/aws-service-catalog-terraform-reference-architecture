import json
import logging
import threading
import boto3
import cfnresponse
import os
import random
from random import *
_rand=str(randint(134324, 12342400))

s3client  = boto3.client('s3')
#aws ken walsh 12-2019
def gen_surl(bucketname,keyname):
    url = s3client.generate_presigned_url(ClientMethod='get_object',Params={'Bucket': bucketname,'Key': keyname})
    return url 
def b_putpriv(bucket,key,body):
  srep = s3client.put_object( ACL='private',Body=body,Bucket=bucket,Key=key, ContentType='text/json',)
  print(srep)
  return srep 

 
def b_get_obj(bucket,bkey):
  object = s3client.get_object(Bucket=bucket,Key=bkey)
  return(object['Body'].read().decode('utf-8') )
  
def b_put(bucket,key,body):
  srep = s3client.put_object(ACL='public-read', Body=body,Bucket=bucket,Key=key, ContentType='text/jso',)
  #print(srep)
  return srep
  
def make_sc_samples_script(event):
    
    sc2  = b_get_obj(event['ResourceProperties']['LogBucket'],'cs/crt-tf-provider-SC_product_sample.json')
    sc2j = json.loads(sc2)
    s3sampletf= 'https://%s.s3.%s.amazonaws.com/cs/aws_tf_s3_sample_cft.json' % (event['ResourceProperties']['LogBucket'],os.environ['AWS_REGION'])
    sc2j['Resources']['Bucket']['Properties']['ProvisioningArtifactParameters'][0]['Info']['LoadTemplateFromURL']=s3sampletf
    b_putpriv(event['ResourceProperties']['LogBucket'],'cs/crt-tf-provider-SC_product_sample.json',json.dumps(sc2j,indent=4))
    # 
    sc1= b_get_obj(event['ResourceProperties']['LogBucket'],'cs/aws_tf_s3_sample.json')
    scj = json.loads(sc1)
    bkey      ='https://%s.s3.%s.amazonaws.com/cs/aws_tf_s3_sample.tf'  % (event['ResourceProperties']['LogBucket'],os.environ['AWS_REGION'])
    scj['Resources']['Terraformsample']['Properties']['ConfigurationUrl']= bkey
    
    b_putpriv(event['ResourceProperties']['LogBucket'],'cs/aws_tf_s3_sample_cft.json',json.dumps(scj,indent=4))
    _s3   ='https://%s.s3.%s.amazonaws.com/cs/aws_tf_s3_sample_cft.json'               % (event['ResourceProperties']['LogBucket'],os.environ['AWS_REGION'])
    _csport  ='https://%s.s3.%s.amazonaws.com/cs/crt-tf-provider-SC_product_sample.json'  % (event['ResourceProperties']['LogBucket'],os.environ['AWS_REGION'])
    _rr=[_s3,_csport]
    #print(_rr)
    return _rr
    
def make_setup_script(event):
    _buf = "#!/bin/bash \n"
    _buf += "TERRAFORMHOST=%s\n"       % event['ResourceProperties']['Terraformhost']
    _buf += "EXECUTION_ROLE_ARN=%s\n" % event['ResourceProperties']['ExecutionRoleArn']
    _buf += "EXECUTION_ROLE_ARN=%s\n" % event['ResourceProperties']['ExecutionRoleArn']
    _buf += "LOGGING_ROLE_ARN=%s\n"   % event['ResourceProperties']['LogRoleArn']
    _buf += "LOG_GROUP_NAME=%s\n"     % event['ResourceProperties']['LogGroupName']
    _buf += "export TERRAFORMHOST\n"      
    _buf += "export EXECUTION_ROLE_ARN\n" 
    _buf += "export LOGGING_ROLE_ARN\n"   
    _buf += "export LOG_GROUP_NAME\n"    
    _buf += "echo setting fingerprint to ssm paramater\n"    
    _buf += "AWS_DEFAULT_REGION=%s\n" %  os.environ['AWS_REGION']
    _buf += "export  AWS_DEFAULT_REGION\n"
    _buf += "fingerprint=`ssh-keygen -E md5 -lf <(ssh-keyscan -t ed25519 $TERRAFORMHOST) | awk '{print substr($2,5,55)}'`\n"
    _buf += "echo fingerprint=[$fingerprint]\n"
    _buf += "aws ssm put-parameter  --name /cfn/terraform/ssh-fingerprint --type 'String' --value $fingerprint --overwrite\n"
    
    _buf += "aws s3 cp s3://%s/cs/cloudsoft-terraform-infrastructure.zip cloudsoft-terraform-infrastructure.zip \n" % (event['ResourceProperties']['LogBucket'])
    _buf += "aws s3 cp --acl public-read cloudsoft-terraform-infrastructure.zip s3://%s/cs/cloudsoft-terraform-infrastructure.zip  \n" % (event['ResourceProperties']['LogBucket'])
    
    _buf += "aws s3 cp s3://%s/cs/aws_tf_s3_sample.tf aws_tf_s3_sample.tf \n" % (event['ResourceProperties']['LogBucket'])
    _buf += "aws s3 cp --acl public-read aws_tf_s3_sample.tf s3://%s/cs/aws_tf_s3_sample.tf \n" % (event['ResourceProperties']['LogBucket'])
    
    _buf += "echo waiting for s3 sync 6 sec\n"
    _buf += "sleep 6\n"
    _buf += "echo registering resource now ..\n"
    _buf += "aws cloudformation register-type  --type RESOURCE --type-name Cloudsoft::Terraform::Infrastructure --schema-handler-package s3://%s/cs/cloudsoft-terraform-infrastructure.zip --execution-role-arn $EXECUTION_ROLE_ARN --logging-config LogRoleArn=$LOGGING_ROLE_ARN,LogGroupName=$LOG_GROUP_NAME\n" % (event['ResourceProperties']['LogBucket'])
   
    _buf += "echo waiting for registration to complete 60 sec ....\n"
    _buf += "sleep 60\n"
    _buf += "echo setting version \n"
    _buf += "_rtype=`aws cloudformation list-types |gre Cloudsoft-Terraform-Infrastructure |grep Arn|awk '{split($2,a,\"\\\"\");print a[2]}'` \n"
    _buf += "_version=`aws cloudformation list-type-versions --arn $_rtype |grep VersionId |sort -r |head -1 |awk '{split($2,a,\"\\\"\");print a[2]}' `\n"
    _buf += "aws cloudformation set-type-default-version  --type RESOURCE  --type-name Cloudsoft::Terraform::Infrastructure  --version-id $_version \n"
    _buf += "echo Version set to $_version now waiting 15 sec for version to sync \n"
    _buf += "sleep 15 \n"
    _buf += "echo Creating Service Catalog sample portfolio\n"
    _buf += "aws cloudformation create-stack --stack-name demoportfolio$RANDOM --template-url https://%s.s3.%s.amazonaws.com/cs/crt-tf-provider-SC_product_sample.json \n"  % (event['ResourceProperties']['LogBucket'],os.environ['AWS_REGION'])
    _buf += "echo Service Catalog sample portfolio is complete. View the AWS CloudFormation Console.\n" 
    
    b_putpriv(event['ResourceProperties']['LogBucket'],'s00setup.sh',_buf)

    print(_buf)
    return _buf
def timeout(event, context):
    logging.error('Execution is about to time out, sending failure response to CloudFormation')
    cfnresponse.send(event, context, cfnresponse.FAILED, {}, None)
def lambda_handler(event, context):
    timer = threading.Timer((context.get_remaining_time_in_millis() / 1000.00) - 0.5, timeout, args=[event, context])
    timer.start()
    print('Received event: %s' % json.dumps(event))
    status = cfnresponse.SUCCESS
    _ret={}
    #return =make_setup_script(event)
    
    try:
        if event['RequestType'] == 'Create':
            event['lstatus'] = 'GotCreateAllGood'
            surl =make_setup_script(event)
            
            _ret['s00setupss3loc']='aws s3 cp  s3://%s/s00setup.sh  s00setup.sh \n' % (event['ResourceProperties']['LogBucket'])
      
            #_ret['SampleCSTF'] =   "ddd"
            _ret['SampleCSTF'] =   make_sc_samples_script(event)[1]
            
    except Exception as e:
        logging.error('Exception: %s' % e, exc_info=True)
        event['lstatus'] = str(e)
        _ret['error'] = str(e)
        status = cfnresponse.FAILED
    finally:
        timer.cancel()
        cfnresponse.send(event, context, status, _ret, None) 
    return(_ret)
     